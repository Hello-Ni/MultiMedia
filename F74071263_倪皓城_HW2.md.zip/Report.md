# Hw1 Video Shot Change Detection
資訊111 F74071263 倪皓城
## Environments
OS: Windows 10/Ubuntu 20.04
Python: 3.7.0
## Visual features
* news、ngc: color histogram
* ftfm: edge detection
## Shot change detection algorithm
### color histogram
1. 將圖片size統一成 (300x300) 形式。
2. 利用opencv split library將RGB每個tunnel獨立出來，丟進colorDegreeCalculate()比較各自tunnel(Red,Blue,Green)的相似度。


    ```python
    def RGB_Historgram(img1, img2, size):
        # compare the similarity between img1 and img2
        img1 = cv2.resize(img1, size)
        img2 = cv2.resize(img2, size)

        rgb_img1 = cv2.split(img1)
        rgb_img2 = cv2.split(img2)
        similarity = 0

        # calculate every tunnel similarity
        for i1, i2 in zip(rgb_img1, rgb_img2):
            similarity = similarity + colorDegreeCalculate(i1, i2)
        similarity = similarity / 3
        return similarity
    ```


3. 將圖片轉為灰階並且劃出histogram，比較兩圖片每長條的差異，如果值不同則相減取絕對值，並且以最大值做為分母相除儲存在degeree variable裡面，因為每個長條圖總數為256條，所以最後的相似度degree必須除以256即為該tunnel顏色的 **相似度**


    ```python
    def colorDegreeCalculate(img1, img2):
        hist1 = cv2.calcHist([img1], [0], None, [256], [0, 256])
        hist2 = cv2.calcHist([img2], [0], None, [256], [0, 256])
        degree = 0

        for i in range(len(hist1)):
            if hist1[i] != hist2[i]:
                #print(hist1[i], hist2[i])

                degree = degree + \
                    (1 - abs(hist1[i] - hist2[i]) / max(hist1[i], hist2[i]))
            else:
                degree = degree+1
        degree = degree/len(hist1)
        return degree
    ```
4. Threshold的部分將每個similarity print出來分析後，定為 **0.8** 可獲得最大Precision
### edge detection
![](https://i.imgur.com/18sWYrG.png)
![](https://i.imgur.com/NRmsPFE.png)
比較兩圖之間，每一格像素如果相同則相似度加一，存入same variable
```python=
def compare_Edge(img1, img2):
    weight1 = img1.shape[1]
    height1 = img1.shape[0]

    same = 0
    for y in range(0, height1-1):
        for x in range(0, weight1-1):
            arrImg1 = img1[y, x, :]
            arrImg2 = img2[y, x, :]

            if (np.array_equal(arrImg1, arrImg2)):
                same += 1
    return same
```

## Performance

| Video name | news | ftfm | ngc 
| -------- | -------- | -------- | --------|
| Algorithm| Color histogram | Edge detection |Color histogram 
| Precision     | 0.875     | 0.127     | 0.675
| Recall     | 1.0     | 0.815     | 0.698
